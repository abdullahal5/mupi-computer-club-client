const Acheivements = () => {
    return (
        <div>
            
        </div>
    );
};

export default Acheivements;