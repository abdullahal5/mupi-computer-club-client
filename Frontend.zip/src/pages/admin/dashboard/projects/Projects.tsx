const Projects = () => {
  return (
    <div className="flex items-center justify-center h-screen text-2xl font-semibold">
      Coming Soon...
    </div>
  );
};

export default Projects;
